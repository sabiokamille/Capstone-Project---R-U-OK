
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		home
	 *	@date 		Saturday 22nd of April 2023 02:40:19 AM
	 *	@title 		v2
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
package com.example.ruokapp.ExtraServices;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

import com.example.ruokapp.R;

	public class appointments_activity extends Activity {

	
	private View _bg__appointments_ek2;
	private TextView upcoming;
	private View line_4;
	private TextView completed;
	private View line_4_ek1;
	private TextView cancelled;
	private View line_3;
	private TextView you_don_t_have_an_appointment_yet;
	private ImageView vector_ek45;
	private ImageView vector_ek46;
	private ImageView vector_ek47;
	private ImageView vector_ek48;
	private ImageView vector_ek49;
	private ImageView vector_ek50;
	private ImageView vector_ek51;
	private ImageView vector_ek52;
	private ImageView vector_ek53;
	private ImageView vector_ek54;
	private ImageView vector_ek55;
	private ImageView vector_ek56;
	private ImageView vector_ek57;
	private ImageView vector_ek58;
	private ImageView vector_ek59;
	private ImageView vector_ek60;
	private ImageView vector_ek61;
	private ImageView vector_ek62;
	private ImageView vector_ek63;
	private ImageView vector_ek64;
	private ImageView vector_ek65;
	private ImageView vector_ek66;
	private ImageView vector_ek67;
	private ImageView vector_ek68;
	private ImageView vector_ek69;
	private ImageView vector_ek70;
	private ImageView vector_ek71;
	private ImageView vector_ek72;
	private ImageView vector_ek73;
	private ImageView vector_ek74;
	private ImageView vector_ek75;
	private ImageView vector_ek76;
	private ImageView vector_ek77;
	private ImageView vector_ek78;
	private ImageView vector_ek79;
	private ImageView vector_ek80;
	private ImageView vector_ek81;
	private ImageView vector_ek82;
	private ImageView vector_ek83;
	private ImageView vector_ek84;
	private ImageView vector_ek85;
	private ImageView vector_ek86;
	private ImageView vector_ek87;
	private ImageView vector_ek88;
	private ImageView vector_ek89;
	private ImageView vector_ek90;
	private ImageView vector_ek91;
	private ImageView vector_ek92;
	private ImageView vector_ek93;
	private ImageView vector_ek94;
	private ImageView vector_ek95;
	private ImageView vector_ek96;
	private ImageView vector_ek97;
	private ImageView vector_ek98;
	private ImageView vector_ek99;
	private ImageView vector_ek100;
	private ImageView vector_ek101;
	private ImageView vector_ek102;
	private ImageView vector_ek103;
	private ImageView vector_ek104;
	private ImageView vector_ek105;
	private ImageView vector_ek106;
	private ImageView vector_ek107;
	private ImageView vector_ek108;
	private ImageView vector_ek109;
	private ImageView vector_ek110;
	private ImageView vector_ek111;
	private ImageView vector_ek112;
	private ImageView vector_ek113;
	private ImageView vector_ek114;
	private ImageView vector_ek115;
	private ImageView vector_ek116;
	private ImageView vector_ek117;
	private ImageView vector_ek118;
	private ImageView vector_ek119;
	private ImageView vector_ek120;
	private ImageView vector_ek121;
	private TextView home_ek3;
	private ImageView vector_ek122;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.appointments);

		
		_bg__appointments_ek2 = (View) findViewById(R.id._bg__appointments_ek2);
		upcoming = (TextView) findViewById(R.id.upcoming);
		line_4 = (View) findViewById(R.id.line_4);
		completed = (TextView) findViewById(R.id.completed);
		line_4_ek1 = (View) findViewById(R.id.line_4_ek1);
		cancelled = (TextView) findViewById(R.id.cancelled);
		line_3 = (View) findViewById(R.id.line_3);
		you_don_t_have_an_appointment_yet = (TextView) findViewById(R.id.you_don_t_have_an_appointment_yet);
		vector_ek45 = (ImageView) findViewById(R.id.vector_ek45);
		vector_ek46 = (ImageView) findViewById(R.id.vector_ek46);
		vector_ek47 = (ImageView) findViewById(R.id.vector_ek47);
		vector_ek48 = (ImageView) findViewById(R.id.vector_ek48);
		vector_ek49 = (ImageView) findViewById(R.id.vector_ek49);
		vector_ek50 = (ImageView) findViewById(R.id.vector_ek50);
		vector_ek51 = (ImageView) findViewById(R.id.vector_ek51);
		vector_ek52 = (ImageView) findViewById(R.id.vector_ek52);
		vector_ek53 = (ImageView) findViewById(R.id.vector_ek53);
		vector_ek54 = (ImageView) findViewById(R.id.vector_ek54);
		vector_ek55 = (ImageView) findViewById(R.id.vector_ek55);
		vector_ek56 = (ImageView) findViewById(R.id.vector_ek56);
		vector_ek57 = (ImageView) findViewById(R.id.vector_ek57);
		vector_ek58 = (ImageView) findViewById(R.id.vector_ek58);
		vector_ek59 = (ImageView) findViewById(R.id.vector_ek59);
		vector_ek60 = (ImageView) findViewById(R.id.vector_ek60);
		vector_ek61 = (ImageView) findViewById(R.id.vector_ek61);
		vector_ek62 = (ImageView) findViewById(R.id.vector_ek62);
		vector_ek63 = (ImageView) findViewById(R.id.vector_ek63);
		vector_ek64 = (ImageView) findViewById(R.id.vector_ek64);
		vector_ek65 = (ImageView) findViewById(R.id.vector_ek65);
		vector_ek66 = (ImageView) findViewById(R.id.vector_ek66);
		vector_ek67 = (ImageView) findViewById(R.id.vector_ek67);
		vector_ek68 = (ImageView) findViewById(R.id.vector_ek68);
		vector_ek69 = (ImageView) findViewById(R.id.vector_ek69);
		vector_ek70 = (ImageView) findViewById(R.id.vector_ek70);
		vector_ek71 = (ImageView) findViewById(R.id.vector_ek71);
		vector_ek72 = (ImageView) findViewById(R.id.vector_ek72);
		vector_ek73 = (ImageView) findViewById(R.id.vector_ek73);
		vector_ek74 = (ImageView) findViewById(R.id.vector_ek74);
		vector_ek75 = (ImageView) findViewById(R.id.vector_ek75);
		vector_ek76 = (ImageView) findViewById(R.id.vector_ek76);
		vector_ek77 = (ImageView) findViewById(R.id.vector_ek77);
		vector_ek78 = (ImageView) findViewById(R.id.vector_ek78);
		vector_ek79 = (ImageView) findViewById(R.id.vector_ek79);
		vector_ek80 = (ImageView) findViewById(R.id.vector_ek80);
		vector_ek81 = (ImageView) findViewById(R.id.vector_ek81);
		vector_ek82 = (ImageView) findViewById(R.id.vector_ek82);
		vector_ek83 = (ImageView) findViewById(R.id.vector_ek83);
		vector_ek84 = (ImageView) findViewById(R.id.vector_ek84);
		vector_ek85 = (ImageView) findViewById(R.id.vector_ek85);
		vector_ek86 = (ImageView) findViewById(R.id.vector_ek86);
		vector_ek87 = (ImageView) findViewById(R.id.vector_ek87);
		vector_ek88 = (ImageView) findViewById(R.id.vector_ek88);
		vector_ek89 = (ImageView) findViewById(R.id.vector_ek89);
		vector_ek90 = (ImageView) findViewById(R.id.vector_ek90);
		vector_ek91 = (ImageView) findViewById(R.id.vector_ek91);
		vector_ek92 = (ImageView) findViewById(R.id.vector_ek92);
		vector_ek93 = (ImageView) findViewById(R.id.vector_ek93);
		vector_ek94 = (ImageView) findViewById(R.id.vector_ek94);
		vector_ek95 = (ImageView) findViewById(R.id.vector_ek95);
		vector_ek96 = (ImageView) findViewById(R.id.vector_ek96);
		vector_ek97 = (ImageView) findViewById(R.id.vector_ek97);
		vector_ek98 = (ImageView) findViewById(R.id.vector_ek98);
		vector_ek99 = (ImageView) findViewById(R.id.vector_ek99);
		vector_ek100 = (ImageView) findViewById(R.id.vector_ek100);
		vector_ek101 = (ImageView) findViewById(R.id.vector_ek101);
		vector_ek102 = (ImageView) findViewById(R.id.vector_ek102);
		vector_ek103 = (ImageView) findViewById(R.id.vector_ek103);
		vector_ek104 = (ImageView) findViewById(R.id.vector_ek104);
		vector_ek105 = (ImageView) findViewById(R.id.vector_ek105);
		vector_ek106 = (ImageView) findViewById(R.id.vector_ek106);
		vector_ek107 = (ImageView) findViewById(R.id.vector_ek107);
		vector_ek108 = (ImageView) findViewById(R.id.vector_ek108);
		vector_ek109 = (ImageView) findViewById(R.id.vector_ek109);
		vector_ek110 = (ImageView) findViewById(R.id.vector_ek110);
		vector_ek111 = (ImageView) findViewById(R.id.vector_ek111);
		vector_ek112 = (ImageView) findViewById(R.id.vector_ek112);
		vector_ek113 = (ImageView) findViewById(R.id.vector_ek113);
		vector_ek114 = (ImageView) findViewById(R.id.vector_ek114);
		vector_ek115 = (ImageView) findViewById(R.id.vector_ek115);
		vector_ek116 = (ImageView) findViewById(R.id.vector_ek116);
		vector_ek117 = (ImageView) findViewById(R.id.vector_ek117);
		vector_ek118 = (ImageView) findViewById(R.id.vector_ek118);
		vector_ek119 = (ImageView) findViewById(R.id.vector_ek119);
		vector_ek120 = (ImageView) findViewById(R.id.vector_ek120);
		vector_ek121 = (ImageView) findViewById(R.id.vector_ek121);
		home_ek3 = (TextView) findViewById(R.id.home_ek3);
		vector_ek122 = (ImageView) findViewById(R.id.vector_ek122);
	
		
		//custom code goes here
		vector_ek122.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {

				Intent nextScreen = new Intent(getApplicationContext(), home_activity.class);
				startActivity(nextScreen);


			}
		});
	
	}
}
	
	