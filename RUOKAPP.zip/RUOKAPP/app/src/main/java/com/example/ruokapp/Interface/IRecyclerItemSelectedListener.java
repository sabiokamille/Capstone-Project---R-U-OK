package com.example.ruokapp.Interface;

import android.view.View;

public interface IRecyclerItemSelectedListener {

    void onItemSelectedListener(View view, int pos);

}
