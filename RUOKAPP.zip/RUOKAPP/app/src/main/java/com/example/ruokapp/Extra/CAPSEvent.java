package com.example.ruokapp.Extra;

import java.util.ArrayList;

public class CAPSEvent {
    private ArrayList<Student> participants;

}
