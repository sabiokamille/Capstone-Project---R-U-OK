
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		home
	 *	@date 		Saturday 22nd of April 2023 02:40:19 AM
	 *	@title 		v2
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package com.example.ruokapp.ExtraServices;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ruokapp.Extra.RunApp;
import com.example.ruokapp.R;
import com.example.ruokapp.Service.HomeActivity;
import com.example.ruokapp.Service.NoteActivity;

	public class home_activity extends Activity {

	
	private View _bg__home_ek2;
	private View journaling_button;
	private ImageView vector;
	private TextView journaling_ek2;
	private View event_button;
	private TextView events_ek2;
	private ImageView vector_ek1;
	private View caps_button;
	private TextView caps_ek2;
	private ImageView star_1;
	private View app_caps;
	private TextView book_appointment;
	private View resource_button;
	private ImageView vector_ek2;
	private TextView resources_ek2;
	private ImageView r_u_ok_1;
	private View free_therapy_rect;
	private View learn_more_rect;
	private TextView learn_more;
	private TextView free_therapy_;
	private ImageView vector_ek3;
	private ImageView vector_ek4;
	private ImageView vector_ek5;
	private ImageView vector_ek6;
	private ImageView vector_ek7;
	private ImageView vector_ek8;
	private ImageView vector_ek9;
	private ImageView vector_ek10;
	private ImageView vector_ek11;
	private ImageView vector_ek12;
	private ImageView vector_ek13;
	private ImageView vector_ek14;
	private ImageView vector_ek15;
	private ImageView vector_ek16;
	private ImageView vector_ek17;
	private ImageView vector_ek18;
	private ImageView vector_ek19;
	private ImageView vector_ek20;
	private ImageView vector_ek21;
	private ImageView vector_ek22;
	private ImageView vector_ek23;
	private ImageView vector_ek24;
	private ImageView vector_ek25;
	private ImageView vector_ek26;
	private ImageView vector_ek27;
	private ImageView vector_ek28;
	private TextView take_an_anonymous_mental_health_survey_today__with_no_strings_attached_;
	private View hotline_rect;
	private ImageView vector_ek29;
	private ImageView vector_ek30;
	private ImageView vector_ek31;
	private ImageView vector_ek32;
	private ImageView vector_ek33;
	private ImageView vector_ek34;
	private ImageView vector_ek35;
	private ImageView vector_ek36;
	private ImageView vector_ek37;
	private ImageView vector_ek38;
	private ImageView vector_ek39;
	private ImageView vector_ek40;
	private ImageView vector_ek41;
	private ImageView vector_ek42;
	private ImageView vector_ek43;
	private ImageView vector_ek44;
	private TextView emergency_hotlines;
	private TextView seeking_immediate_help__speak_to_a_real_person_at_the_dial_;
	private View call_hotline_button;
	private TextView call_hotline;
	private TextView logout;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.home);

		
		_bg__home_ek2 = (View) findViewById(R.id._bg__home_ek2);
		journaling_button = (View) findViewById(R.id.journaling_button);
		vector = (ImageView) findViewById(R.id.vector);
		journaling_ek2 = (TextView) findViewById(R.id.journaling_ek2);
		event_button = (View) findViewById(R.id.event_button);
		events_ek2 = (TextView) findViewById(R.id.events_ek2);
		vector_ek1 = (ImageView) findViewById(R.id.vector_ek1);
		caps_button = (View) findViewById(R.id.caps_button);
		caps_ek2 = (TextView) findViewById(R.id.caps_ek2);
		star_1 = (ImageView) findViewById(R.id.star_1);
		app_caps = (View) findViewById(R.id.app_caps);
		book_appointment = (TextView) findViewById(R.id.book_appointment);
		resource_button = (View) findViewById(R.id.resource_button);
		vector_ek2 = (ImageView) findViewById(R.id.vector_ek2);
		resources_ek2 = (TextView) findViewById(R.id.resources_ek2);
		r_u_ok_1 = (ImageView) findViewById(R.id.r_u_ok_1);
		free_therapy_rect = (View) findViewById(R.id.free_therapy_rect);
		learn_more_rect = (View) findViewById(R.id.learn_more_rect);
		learn_more = (TextView) findViewById(R.id.learn_more);
		free_therapy_ = (TextView) findViewById(R.id.free_therapy_);
		vector_ek3 = (ImageView) findViewById(R.id.vector_ek3);
		vector_ek4 = (ImageView) findViewById(R.id.vector_ek4);
		vector_ek5 = (ImageView) findViewById(R.id.vector_ek5);
		vector_ek6 = (ImageView) findViewById(R.id.vector_ek6);
		vector_ek7 = (ImageView) findViewById(R.id.vector_ek7);
		vector_ek8 = (ImageView) findViewById(R.id.vector_ek8);
		vector_ek9 = (ImageView) findViewById(R.id.vector_ek9);
		vector_ek10 = (ImageView) findViewById(R.id.vector_ek10);
		vector_ek11 = (ImageView) findViewById(R.id.vector_ek11);
		vector_ek12 = (ImageView) findViewById(R.id.vector_ek12);
		vector_ek13 = (ImageView) findViewById(R.id.vector_ek13);
		vector_ek14 = (ImageView) findViewById(R.id.vector_ek14);
		vector_ek15 = (ImageView) findViewById(R.id.vector_ek15);
		vector_ek16 = (ImageView) findViewById(R.id.vector_ek16);
		vector_ek17 = (ImageView) findViewById(R.id.vector_ek17);
		vector_ek18 = (ImageView) findViewById(R.id.vector_ek18);
		vector_ek19 = (ImageView) findViewById(R.id.vector_ek19);
		vector_ek20 = (ImageView) findViewById(R.id.vector_ek20);
		vector_ek21 = (ImageView) findViewById(R.id.vector_ek21);
		vector_ek22 = (ImageView) findViewById(R.id.vector_ek22);
		vector_ek23 = (ImageView) findViewById(R.id.vector_ek23);
		vector_ek24 = (ImageView) findViewById(R.id.vector_ek24);
		vector_ek25 = (ImageView) findViewById(R.id.vector_ek25);
		vector_ek26 = (ImageView) findViewById(R.id.vector_ek26);
		vector_ek27 = (ImageView) findViewById(R.id.vector_ek27);
		vector_ek28 = (ImageView) findViewById(R.id.vector_ek28);
		take_an_anonymous_mental_health_survey_today__with_no_strings_attached_ = (TextView) findViewById(R.id.take_an_anonymous_mental_health_survey_today__with_no_strings_attached_);
		hotline_rect = (View) findViewById(R.id.hotline_rect);
		vector_ek29 = (ImageView) findViewById(R.id.vector_ek29);
		vector_ek30 = (ImageView) findViewById(R.id.vector_ek30);
		vector_ek31 = (ImageView) findViewById(R.id.vector_ek31);
		vector_ek32 = (ImageView) findViewById(R.id.vector_ek32);
		vector_ek33 = (ImageView) findViewById(R.id.vector_ek33);
		vector_ek34 = (ImageView) findViewById(R.id.vector_ek34);
		vector_ek35 = (ImageView) findViewById(R.id.vector_ek35);
		vector_ek36 = (ImageView) findViewById(R.id.vector_ek36);
		vector_ek37 = (ImageView) findViewById(R.id.vector_ek37);
		vector_ek38 = (ImageView) findViewById(R.id.vector_ek38);
		vector_ek39 = (ImageView) findViewById(R.id.vector_ek39);
		vector_ek40 = (ImageView) findViewById(R.id.vector_ek40);
		vector_ek41 = (ImageView) findViewById(R.id.vector_ek41);
		vector_ek42 = (ImageView) findViewById(R.id.vector_ek42);
		vector_ek43 = (ImageView) findViewById(R.id.vector_ek43);
		vector_ek44 = (ImageView) findViewById(R.id.vector_ek44);
		emergency_hotlines = (TextView) findViewById(R.id.emergency_hotlines);
		seeking_immediate_help__speak_to_a_real_person_at_the_dial_ = (TextView) findViewById(R.id.seeking_immediate_help__speak_to_a_real_person_at_the_dial_);
		call_hotline_button = (View) findViewById(R.id.call_hotline_button);
		call_hotline = (TextView) findViewById(R.id.call_hotline);
		logout = (TextView) findViewById(R.id.logout);
	
		
		//custom code goes here
		app_caps.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {

				Intent nextScreen = new Intent(getApplicationContext(), HomeActivity.class);
				startActivity(nextScreen);


			}
		});

		journaling_button.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {

				Intent nextScreen = new Intent(getApplicationContext(), NoteActivity.class);
				startActivity(nextScreen);


			}
		});


		event_button.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {

				Intent nextScreen = new Intent(getApplicationContext(), events_activity.class);
				startActivity(nextScreen);


			}
		});

		resource_button.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {

				Intent nextScreen = new Intent(getApplicationContext(), resources___main_page___top_page_activity.class);
				startActivity(nextScreen);


			}
		});

		call_hotline_button.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.apa.org/topics/crisis-hotlines"));
				startActivity(browserIntent);
			}
		});

		learn_more_rect.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.psychologytoday.com/us/tests/health/mental-health-assessment"));
				startActivity(browserIntent);
			}
		});

		caps_button.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://health.rutgers.edu/medical-counseling-services/counseling/"));
				startActivity(browserIntent);
			}
		});

		/**I AM GONNA TRY TO ADD LOGOUT BUTTON TO HOME PAGE IF NOT WORK CHANGE LOGOUT TO VIEW INSTEAD OF TEXTVIEW */
		logout.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent nextScreen = new Intent(getApplicationContext(), RunApp.class);
				startActivity(nextScreen);
			}
		});
	
	}
}
	
	